package com.javatpoint.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javatpoint.dbconnect.DBConnect;
import com.javatpoint.model.Employee;

@Controller
public class ControllerClass {
	
	@RequestMapping("/")
	public String home( ) {
		return "home";
	}
	
	@RequestMapping("/home")
	public String homePage( ) {
		return "home";
	}
	
	@RequestMapping("/panBulk")
	public String panBulk( ) {
		return "panBulk";
	}
	
	@RequestMapping("/downloadFiles")
	public String downloadFiles( ) {
		return "downloadFiles";
	}
	
	@RequestMapping("/uploadFiles")
	public String uploadFiles( ) {
		return "uploadFiles";
	}
	
	@RequestMapping("/success")
	public String success(@RequestParam("username") String name, 
			@RequestParam("password") String pass, Model model) throws ClassNotFoundException, SQLException {
		Connection con = DBConnect.getConnection();
			
		PreparedStatement stmt = con.prepareStatement("select * from employee where emp_name=? and emp_pass=?");
		stmt.setString(1, name);
		stmt.setString(2, pass);

		ResultSet rs = stmt.executeQuery();
		
		Employee emp = new Employee();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"=="+rs.getString(2)+
					"=="+rs.getString(3)+"=="+rs.getString(4));
			emp.setEmp_id(rs.getInt(1));
			emp.setEmp_name(rs.getString(2));
			emp.setEmp_pass(rs.getString(3));
			emp.setEmp_mail(rs.getString(4));
		}
		
		if(name.equals(emp.getEmp_name()) && pass.equals(emp.getEmp_pass())) {
			model.addAttribute("vn",emp.getEmp_name());
			model.addAttribute("vp",emp.getEmp_pass());
			model.addAttribute("id",emp.getEmp_id());
			model.addAttribute("e",emp.getEmp_mail());
			return "success";
		} else {
			model.addAttribute("un","invalid name");
			model.addAttribute("up","invalid pass");
			System.out.println(emp.getEmp_name()+"---"+emp.getEmp_pass());
			model.addAttribute("invalid", "invalid user");
//			model.addAttribute("id",emp.getEmp_id());
//			model.addAttribute("e",emp.getEmp_mail());
			return "home";
		} 
	}
}
