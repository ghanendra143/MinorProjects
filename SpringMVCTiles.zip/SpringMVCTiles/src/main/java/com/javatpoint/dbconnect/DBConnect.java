package com.javatpoint.dbconnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://localhost;databaseName=rahul;instanceName=SQLEXPRESS;user=ghanendra;password=pass1234");  
		} 
		catch (ClassNotFoundException | SQLException e) {
		}
		return con;
		}
}
