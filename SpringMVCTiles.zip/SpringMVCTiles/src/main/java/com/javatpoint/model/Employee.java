package com.javatpoint.model;

public class Employee {
	
	private int emp_id;
	private String emp_name;
	private String emp_pass;
	private String emp_mail;
	
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getEmp_pass() {
		return emp_pass;
	}
	public void setEmp_pass(String emp_pass) {
		this.emp_pass = emp_pass;
	}
	public String getEmp_mail() {
		return emp_mail;
	}
	public void setEmp_mail(String emp_mail) {
		this.emp_mail = emp_mail;
	}
	
	public Employee(int emp_id, String emp_name, String emp_pass, String emp_mail) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_pass = emp_pass;
		this.emp_mail = emp_mail;
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_pass=" + emp_pass + ", emp_mail="
				+ emp_mail + "]";
	}
}
